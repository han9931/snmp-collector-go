// 节点管理JavaScript文件
let nodes = [];
let currentNode = null;

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', function() {
    loadNodes();
});

// 加载所有节点
async function loadNodes() {
    showLoading(true);
    try {
        const response = await fetch('/api/nodes');
        if (response.ok) {
            const result = await response.json();
            // 解析API响应的data字段
            nodes = result.data || [];
            renderNodes();
        } else {
            showMessage('加载节点失败', 'error');
        }
    } catch (error) {
        console.error('Error loading nodes:', error);
        showMessage('网络错误，无法加载节点', 'error');
    } finally {
        showLoading(false);
    }
}

// 渲染节点卡片
function renderNodes() {
    const grid = document.getElementById('nodesGrid');
    if (nodes.length === 0) {
        grid.innerHTML = `
            <div style="grid-column: 1 / -1; text-align: center; padding: 40px; color: #666;">
                <i class="fas fa-server" style="font-size: 48px; margin-bottom: 15px; opacity: 0.5;"></i>
                <p>暂无节点数据</p>
                <p style="font-size: 14px;">点击"添加节点"按钮创建第一个节点</p>
            </div>
        `;
        return;
    }

    grid.innerHTML = nodes.map(node => `
        <div class="node-card">
            <div class="node-header">
                <div class="node-name">${node.name}</div>
                <div class="node-status ${node.status === 'active' ? 'status-active' : 'status-inactive'}">
                    ${node.status === 'active' ? '启用' : '禁用'}
                </div>
            </div>
            <div class="node-description">${node.description || '暂无描述'}</div>
            <div class="node-stats">
                <div class="stat-item">
                    <div class="stat-number" id="accessCount-${node.id}">-</div>
                    <div class="stat-label">接入交换机</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number" id="gatewayCount-${node.id}">-</div>
                    <div class="stat-label">网关交换机</div>
                </div>
            </div>
            <div class="node-actions">
                <button class="btn btn-primary" onclick="showConfigModal(${node.id})">
                    <i class="fas fa-cog"></i> 配置
                </button>
                <button class="btn btn-success" onclick="showScheduleModal(${node.id})">
                    <i class="fas fa-clock"></i> 调度
                </button>
                <button class="btn btn-warning" onclick="editNode(${node.id})">
                    <i class="fas fa-edit"></i> 编辑
                </button>
                <button class="btn btn-danger" onclick="deleteNode(${node.id})">
                    <i class="fas fa-trash"></i> 删除
                </button>
            </div>
        </div>
    `).join('');

    // 加载每个节点的配置统计
    nodes.forEach(node => {
        loadNodeStats(node.id);
    });
}

// 加载节点统计信息
async function loadNodeStats(nodeId) {
    try {
        const response = await fetch(`/api/nodes/configs?node_id=${nodeId}`);
        if (response.ok) {
            const result = await response.json();
            const configs = result.data || [];
            let accessCount = 0, gatewayCount = 0;
            
            configs.forEach(config => {
                const count = config.ip_addresses ? config.ip_addresses.split('\n').filter(ip => ip.trim()).length : 0;
                if (config.config_type === 'access_switches') {
                    accessCount = count;
                } else if (config.config_type === 'gateway_switches') {
                    gatewayCount = count;
                }
            });
            
            document.getElementById(`accessCount-${nodeId}`).textContent = accessCount;
            document.getElementById(`gatewayCount-${nodeId}`).textContent = gatewayCount;
        }
    } catch (error) {
        console.error('Error loading node stats:', error);
    }
}

// 显示添加节点模态框
function showAddNodeModal() {
    currentNode = null;
    document.getElementById('nodeModalTitle').textContent = '添加节点';
    document.getElementById('nodeName').value = '';
    document.getElementById('nodeDescription').value = '';
    document.getElementById('nodeStatus').value = 'active';
    document.getElementById('nodeModal').style.display = 'block';
}

// 编辑节点
function editNode(nodeId) {
    const node = nodes.find(n => n.id === nodeId);
    if (!node) return;
    
    currentNode = node;
    document.getElementById('nodeModalTitle').textContent = '编辑节点';
    document.getElementById('nodeName').value = node.name;
    document.getElementById('nodeDescription').value = node.description || '';
    document.getElementById('nodeStatus').value = node.status;
    document.getElementById('nodeModal').style.display = 'block';
}

// 关闭节点模态框
function closeNodeModal() {
    document.getElementById('nodeModal').style.display = 'none';
    currentNode = null;
}

// 保存节点
document.getElementById('nodeForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const name = document.getElementById('nodeName').value.trim();
    const description = document.getElementById('nodeDescription').value.trim();
    const status = document.getElementById('nodeStatus').value;
    
    if (!name) {
        showMessage('请输入节点名称', 'error');
        return;
    }
    
    const nodeData = { name, description, status };
    
    try {
        let response;
        if (currentNode) {
            // 更新节点
            response = await fetch(`/api/nodes/${currentNode.id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(nodeData)
            });
        } else {
            // 创建节点
            response = await fetch('/api/nodes', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(nodeData)
            });
        }
        
        if (response.ok) {
            showMessage(currentNode ? '节点更新成功' : '节点创建成功', 'success');
            closeNodeModal();
            loadNodes();
        } else {
            const error = await response.text();
            showMessage(error || '操作失败', 'error');
        }
    } catch (error) {
        console.error('Error saving node:', error);
        showMessage('网络错误，操作失败', 'error');
    }
});

// 删除节点
async function deleteNode(nodeId) {
    const node = nodes.find(n => n.id === nodeId);
    if (!node) return;
    
    if (!confirm(`确定要删除节点 "${node.name}" 吗？\n删除后相关的配置和数据将无法恢复。`)) {
        return;
    }
    
    try {
        const response = await fetch(`/api/nodes/${nodeId}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            showMessage('节点删除成功', 'success');
            loadNodes();
        } else {
            const error = await response.text();
            showMessage(error || '删除失败', 'error');
        }
    } catch (error) {
        console.error('Error deleting node:', error);
        showMessage('网络错误，删除失败', 'error');
    }
}

// 显示配置管理模态框
async function showConfigModal(nodeId) {
    const node = nodes.find(n => n.id === nodeId);
    if (!node) return;
    
    document.getElementById('configModal').style.display = 'block';
    
    // 加载配置数据
    try {
        const response = await fetch(`/api/nodes/configs?node_id=${nodeId}`);
        if (response.ok) {
            const result = await response.json();
            const configs = result.data || [];
            renderConfigContent(nodeId, configs);
        } else {
            document.getElementById('configContent').innerHTML = '<p>加载配置失败</p>';
        }
    } catch (error) {
        console.error('Error loading configs:', error);
        document.getElementById('configContent').innerHTML = '<p>网络错误，无法加载配置</p>';
    }
}

// 渲染配置内容
function renderConfigContent(nodeId, configs) {
    const accessConfig = configs.find(c => c.config_type === 'access_switches');
    const gatewayConfig = configs.find(c => c.config_type === 'gateway_switches');
    
    document.getElementById('configContent').innerHTML = `
        <div class="config-section">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                <h3>接入交换机配置</h3>
                ${accessConfig ? `<button class="btn btn-danger" onclick="deleteConfig(${nodeId}, 'access_switches')" style="font-size: 12px; padding: 4px 8px;"><i class="fas fa-trash"></i> 删除</button>` : ''}
            </div>
            <div class="form-group">
                <label class="form-label">IP地址列表 (每行一个IP)</label>
                <textarea id="accessIPs" class="form-control textarea" rows="8" placeholder="例如：&#10;192.168.1.1&#10;192.168.1.2">${accessConfig ? accessConfig.ip_addresses : ''}</textarea>
            </div>
            <div class="form-group">
                <label class="form-label">或上传配置文件</label>
                <div class="upload-area" ondrop="handleFileDrop(event, 'access_switches', ${nodeId})" ondragover="handleDragOver(event)">
                    <i class="fas fa-upload"></i>
                    <p>拖拽文件到此处或 <input type="file" id="accessFile" style="display: none;" onchange="handleFileSelect(event, 'access_switches', ${nodeId})"><label for="accessFile" style="color: #007bff; cursor: pointer;">点击选择文件</label></p>
                </div>
            </div>
        </div>
        
        <div class="config-section" style="margin-top: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                <h3>网关交换机配置</h3>
                ${gatewayConfig ? `<button class="btn btn-danger" onclick="deleteConfig(${nodeId}, 'gateway_switches')" style="font-size: 12px; padding: 4px 8px;"><i class="fas fa-trash"></i> 删除</button>` : ''}
            </div>
            <div class="form-group">
                <label class="form-label">IP地址列表 (每行一个IP)</label>
                <textarea id="gatewayIPs" class="form-control textarea" rows="8" placeholder="例如：&#10;10.0.0.1&#10;10.0.0.2">${gatewayConfig ? gatewayConfig.ip_addresses : ''}</textarea>
            </div>
            <div class="form-group">
                <label class="form-label">或上传配置文件</label>
                <div class="upload-area" ondrop="handleFileDrop(event, 'gateway_switches', ${nodeId})" ondragover="handleDragOver(event)">
                    <i class="fas fa-upload"></i>
                    <p>拖拽文件到此处或 <input type="file" id="gatewayFile" style="display: none;" onchange="handleFileSelect(event, 'gateway_switches', ${nodeId})"><label for="gatewayFile" style="color: #007bff; cursor: pointer;">点击选择文件</label></p>
                </div>
            </div>
        </div>
        
        <div class="form-actions">
            <button type="button" class="btn btn-secondary" onclick="closeConfigModal()">取消</button>
            <button type="button" class="btn btn-primary" onclick="saveConfigs(${nodeId})">保存配置</button>
        </div>
    `;
}

// 保存配置
async function saveConfigs(nodeId) {
    const accessIPs = document.getElementById('accessIPs').value.trim();
    const gatewayIPs = document.getElementById('gatewayIPs').value.trim();
    
    try {
        // 保存接入交换机配置
        if (accessIPs) {
            const response = await fetch('/api/nodes/configs', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    node_id: nodeId,
                    config_type: 'access_switches',
                    ip_addresses: accessIPs
                })
            });
            if (!response.ok) {
                throw new Error('保存接入交换机配置失败');
            }
        }
        
        // 保存网关交换机配置
        if (gatewayIPs) {
            const response = await fetch('/api/nodes/configs', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    node_id: nodeId,
                    config_type: 'gateway_switches',
                    ip_addresses: gatewayIPs
                })
            });
            if (!response.ok) {
                throw new Error('保存网关交换机配置失败');
            }
        }
        
        showMessage('配置保存成功', 'success');
        closeConfigModal();
        loadNodes(); // 重新加载以更新统计
    } catch (error) {
        console.error('Error saving configs:', error);
        showMessage(error.message || '保存配置失败', 'error');
    }
}

// 关闭配置模态框
function closeConfigModal() {
    document.getElementById('configModal').style.display = 'none';
}

// 显示调度管理模态框
async function showScheduleModal(nodeId) {
    const node = nodes.find(n => n.id === nodeId);
    if (!node) return;
    
    document.getElementById('scheduleModal').style.display = 'block';
    
    // 加载调度数据
    try {
        const response = await fetch(`/api/nodes/schedules?node_id=${nodeId}`);
        if (response.ok) {
            const result = await response.json();
            const schedules = result.data || [];
            renderScheduleContent(nodeId, schedules);
        } else {
            document.getElementById('scheduleContent').innerHTML = '<p>加载调度配置失败</p>';
        }
    } catch (error) {
        console.error('Error loading schedules:', error);
        document.getElementById('scheduleContent').innerHTML = '<p>网络错误，无法加载调度配置</p>';
    }
}

// 渲染调度内容
function renderScheduleContent(nodeId, schedules) {
    const accessSchedule = schedules.find(s => s.schedule_type === 'access_switches');
    const gatewaySchedule = schedules.find(s => s.schedule_type === 'gateway_switches');
    
    document.getElementById('scheduleContent').innerHTML = `
        <div class="schedule-grid">
            <div class="schedule-item">
                <div class="schedule-type">接入交换机调度</div>
                <div class="form-group">
                    <label class="form-label">更新间隔 (分钟)</label>
                    <input type="number" id="accessInterval" class="form-control" min="1" value="${accessSchedule ? accessSchedule.interval_minutes : 30}">
                </div>
                <div class="form-group">
                    <label class="form-label">启用状态</label>
                    <select id="accessEnabled" class="form-control">
                        <option value="true" ${accessSchedule && accessSchedule.is_enabled ? 'selected' : ''}>启用</option>
                        <option value="false" ${accessSchedule && !accessSchedule.is_enabled ? 'selected' : ''}>禁用</option>
                    </select>
                </div>
                ${accessSchedule ? `
                    <div class="schedule-info">上次运行: ${accessSchedule.last_run_at || '从未运行'}</div>
                    <div class="schedule-info">下次运行: ${accessSchedule.next_run_at || '未安排'}</div>
                ` : ''}
            </div>
            
            <div class="schedule-item">
                <div class="schedule-type">网关交换机调度</div>
                <div class="form-group">
                    <label class="form-label">更新间隔 (分钟)</label>
                    <input type="number" id="gatewayInterval" class="form-control" min="1" value="${gatewaySchedule ? gatewaySchedule.interval_minutes : 30}">
                </div>
                <div class="form-group">
                    <label class="form-label">启用状态</label>
                    <select id="gatewayEnabled" class="form-control">
                        <option value="true" ${gatewaySchedule && gatewaySchedule.is_enabled ? 'selected' : ''}>启用</option>
                        <option value="false" ${gatewaySchedule && !gatewaySchedule.is_enabled ? 'selected' : ''}>禁用</option>
                    </select>
                </div>
                ${gatewaySchedule ? `
                    <div class="schedule-info">上次运行: ${gatewaySchedule.last_run_at || '从未运行'}</div>
                    <div class="schedule-info">下次运行: ${gatewaySchedule.next_run_at || '未安排'}</div>
                ` : ''}
            </div>
        </div>
        
        <div class="form-actions">
            <button type="button" class="btn btn-secondary" onclick="closeScheduleModal()">取消</button>
            <button type="button" class="btn btn-primary" onclick="saveSchedules(${nodeId})">保存调度</button>
        </div>
    `;
}

// 保存调度配置
async function saveSchedules(nodeId) {
    const accessInterval = parseInt(document.getElementById('accessInterval').value);
    const accessEnabled = document.getElementById('accessEnabled').value === 'true';
    const gatewayInterval = parseInt(document.getElementById('gatewayInterval').value);
    const gatewayEnabled = document.getElementById('gatewayEnabled').value === 'true';
    
    if (accessInterval < 1 || gatewayInterval < 1) {
        showMessage('更新间隔必须大于0分钟', 'error');
        return;
    }
    
    try {
        // 保存接入交换机调度
        const accessResponse = await fetch('/api/nodes/schedules', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                node_id: nodeId,
                schedule_type: 'access_switches',
                interval_minutes: accessInterval,
                is_enabled: accessEnabled
            })
        });
        if (!accessResponse.ok) {
            throw new Error('保存接入交换机调度失败');
        }
        
        // 保存网关交换机调度
        const gatewayResponse = await fetch('/api/nodes/schedules', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                node_id: nodeId,
                schedule_type: 'gateway_switches',
                interval_minutes: gatewayInterval,
                is_enabled: gatewayEnabled
            })
        });
        if (!gatewayResponse.ok) {
            throw new Error('保存网关交换机调度失败');
        }
        
        showMessage('调度配置保存成功', 'success');
        closeScheduleModal();
    } catch (error) {
        console.error('Error saving schedules:', error);
        showMessage(error.message || '保存调度配置失败', 'error');
    }
}

// 关闭调度模态框
function closeScheduleModal() {
    document.getElementById('scheduleModal').style.display = 'none';
}

// 文件拖拽处理
function handleDragOver(event) {
    event.preventDefault();
    event.currentTarget.classList.add('dragover');
}

function handleFileDrop(event, configType, nodeId) {
    event.preventDefault();
    event.currentTarget.classList.remove('dragover');
    
    const files = event.dataTransfer.files;
    if (files.length > 0) {
        uploadConfigFile(files[0], configType, nodeId);
    }
}

function handleFileSelect(event, configType, nodeId) {
    const files = event.target.files;
    if (files.length > 0) {
        uploadConfigFile(files[0], configType, nodeId);
    }
}

// 上传配置文件
async function uploadConfigFile(file, configType, nodeId) {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('node_id', nodeId);
    formData.append('config_type', configType);
    
    try {
        const response = await fetch('/api/upload', {
            method: 'POST',
            body: formData
        });
        
        if (response.ok) {
            const result = await response.json();
            showMessage('文件上传成功', 'success');
            
            // 更新对应的文本框
            const textareaId = configType === 'access_switches' ? 'accessIPs' : 'gatewayIPs';
            document.getElementById(textareaId).value = result.ip_addresses;
        } else {
            const error = await response.text();
            showMessage(error || '文件上传失败', 'error');
        }
    } catch (error) {
        console.error('Error uploading file:', error);
        showMessage('网络错误，文件上传失败', 'error');
    }
}

// 显示消息
function showMessage(message, type) {
    const container = document.getElementById('messageContainer');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message message-${type}`;
    messageDiv.textContent = message;
    
    container.appendChild(messageDiv);
    
    // 3秒后自动移除消息
    setTimeout(() => {
        if (messageDiv.parentNode) {
            messageDiv.parentNode.removeChild(messageDiv);
        }
    }, 3000);
}

// 显示/隐藏加载状态
function showLoading(show) {
    document.getElementById('loadingContainer').style.display = show ? 'block' : 'none';
    document.getElementById('nodesGrid').style.display = show ? 'none' : 'grid';
}

// 删除配置
async function deleteConfig(nodeId, configType) {
    const typeName = configType === 'access_switches' ? '接入交换机' : '网关交换机';
    
    if (!confirm(`确定要删除${typeName}配置吗？\n删除后相关的IP地址列表将被清空。`)) {
        return;
    }
    
    try {
        const response = await fetch(`/api/nodes/configs?node_id=${nodeId}&config_type=${configType}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            showMessage(`${typeName}配置删除成功`, 'success');
            // 重新加载配置对话框
            showConfigModal(nodeId);
            // 重新加载节点列表以更新统计
            loadNodes();
        } else {
            const error = await response.text();
            showMessage(error || '删除失败', 'error');
        }
    } catch (error) {
        console.error('Error deleting config:', error);
        showMessage('网络错误，删除失败', 'error');
    }
}

// 点击模态框外部关闭
window.onclick = function(event) {
    const nodeModal = document.getElementById('nodeModal');
    const configModal = document.getElementById('configModal');
    const scheduleModal = document.getElementById('scheduleModal');
    
    if (event.target === nodeModal) {
        closeNodeModal();
    } else if (event.target === configModal) {
        closeConfigModal();
    } else if (event.target === scheduleModal) {
        closeScheduleModal();
    }
};