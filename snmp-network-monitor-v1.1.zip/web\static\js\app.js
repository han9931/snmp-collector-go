// 应用程序主类
class NetworkMonitorApp {
    constructor() {
        this.currentTab = 'topology';
        this.currentPage = 1;
        this.pageSize = 20;
        this.currentSearchTerm = '';
        this.currentView = 'table'; // 'table' 或 'diagram'
        this.topologyData = []; // 存储拓扑数据以便绘制图形
        this.selectedNodeId = ''; // 当前选中的节点ID
        this.nodes = []; // 存储节点列表
        
        // 缩放和平移相关属性
        this.zoomLevel = 1;
        this.minZoom = 0.2;
        this.maxZoom = 3;
        this.panX = 0;
        this.panY = 0;
        this.isDragging = false;
        this.lastMouseX = 0;
        this.lastMouseY = 0;
        
        this.init();
    }

    // 初始化应用程序
    init() {
        this.setupEventListeners();
        this.loadNodes();
        
        // 从URL参数中获取节点ID
        const urlParams = new URLSearchParams(window.location.search);
        const nodeId = urlParams.get('node_id');
        if (nodeId) {
            this.selectedNodeId = nodeId;
        }
    }

    // 设置事件监听器
    setupEventListeners() {
        // 标签页切换
        document.querySelectorAll('.tab-button').forEach(button => {
            button.addEventListener('click', (e) => {
                const tabName = e.target.getAttribute('data-tab');
                this.switchTab(tabName);
            });
        });

        // 搜索功能
        document.getElementById('searchBtn').addEventListener('click', () => {
            this.performSearch();
        });

        document.getElementById('clearBtn').addEventListener('click', () => {
            this.clearSearch();
        });

        document.getElementById('searchInput').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.performSearch();
            }
        });

        // 头部按钮
        document.getElementById('statusBtn').addEventListener('click', () => {
            this.showStatus();
        });

        document.getElementById('collectBtn').addEventListener('click', () => {
            this.triggerCollection();
        });

        document.getElementById('reloadBtn').addEventListener('click', () => {
            this.reloadConfig();
        });

        // 模态框关闭
        document.querySelector('.close').addEventListener('click', () => {
            this.closeModal();
        });

        // 点击模态框外部关闭
        document.getElementById('statusModal').addEventListener('click', (e) => {
            if (e.target.id === 'statusModal') {
                this.closeModal();
            }
        });

        // 拓扑图视图切换
        document.getElementById('tableViewBtn').addEventListener('click', () => {
            this.switchView('table');
        });

        document.getElementById('diagramViewBtn').addEventListener('click', () => {
            this.switchView('diagram');
        });
        
        // 节点选择器事件
        const nodeSelect = document.getElementById('nodeSelect');
        if (nodeSelect) {
            nodeSelect.addEventListener('change', (e) => {
                this.handleNodeChange(e.target.value);
            });
        }
    }

    // 加载节点列表
    async loadNodes() {
        try {
            const response = await fetch('/api/nodes');
            if (response.ok) {
                const result = await response.json();
                this.nodes = result.data || [];
                
                const nodeSelect = document.getElementById('nodeSelect');
                if (nodeSelect) {
                    this.populateNodeSelector(nodeSelect);
                }
                
                // 加载完节点后，加载拓扑数据
                this.loadTopologyData();
            } else {
                console.error('加载节点失败');
                this.showMessage('加载节点失败', 'error');
                // 即使加载节点失败，也要加载拓扑数据
                this.loadTopologyData();
            }
        } catch (error) {
            console.error('网络错误，无法加载节点:', error);
            this.showMessage('网络错误，无法加载节点', 'error');
            // 即使加载节点失败，也要加载拓扑数据
            this.loadTopologyData();
        }
    }
    
    // 填充节点选择器
    populateNodeSelector(nodeSelect) {
        // 清空现有选项
        nodeSelect.innerHTML = '';
        
        // 添加默认选项
        const defaultOption = document.createElement('option');
        defaultOption.value = '';
        defaultOption.textContent = '请选择节点';
        nodeSelect.appendChild(defaultOption);
        
        // 添加节点选项
        const activeNodes = this.nodes.filter(node => node.status === 'active');
        activeNodes.forEach(node => {
            const option = document.createElement('option');
            option.value = node.id;
            option.textContent = node.name;
            nodeSelect.appendChild(option);
        });
        
        // 如果有预选的节点ID，设置选中状态
        if (this.selectedNodeId) {
            nodeSelect.value = this.selectedNodeId;
        } else if (activeNodes.length === 1) {
            // 如果只有一个节点，自动选中
            nodeSelect.value = activeNodes[0].id;
            this.selectedNodeId = activeNodes[0].id;
        }
    }
    
    // 处理节点选择变更
    handleNodeChange(nodeId) {
        this.selectedNodeId = nodeId;
        this.currentPage = 1;
        this.currentSearchTerm = '';
        
        // 清空搜索框
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.value = '';
        }
        
        // 重新加载数据
        switch (this.currentTab) {
            case 'topology':
                this.loadTopologyData();
                break;
            case 'mac-interfaces':
                this.loadMacInterfaceData();
                break;
            case 'ip-interfaces':
                this.loadIPInterfaceData();
                break;
        }
    }

    // 切换标签页
    switchTab(tabName) {
        // 更新标签按钮状态
        document.querySelectorAll('.tab-button').forEach(button => {
            button.classList.remove('active');
        });
        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');

        // 更新标签页内容
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });
        document.getElementById(tabName).classList.add('active');

        this.currentTab = tabName;
        this.currentPage = 1;

        // 加载对应的数据
        switch (tabName) {
            case 'topology':
                this.loadTopologyData();
                break;
            case 'mac-interfaces':
                this.loadMacInterfaceData();
                break;
            case 'ip-interfaces':
                this.loadIPInterfaceData();
                break;
        }
    }

    // 执行搜索
    performSearch() {
        const searchTerm = document.getElementById('searchInput').value.trim();
        if (!searchTerm) {
            this.showMessage('请输入搜索关键词', 'warning');
            return;
        }

        this.currentSearchTerm = searchTerm;
        this.currentPage = 1;

        if (this.currentTab === 'topology') {
            this.loadTopologyData(true);
        }
    }

    // 清空搜索
    clearSearch() {
        document.getElementById('searchInput').value = '';
        this.currentSearchTerm = '';
        this.currentPage = 1;

        if (this.currentTab === 'topology') {
            this.loadTopologyData();
        }
    }

    // 加载网络拓扑数据
    async loadTopologyData(isSearch = false) {
        console.log('🔄 开始加载网络拓扑数据, isSearch:', isSearch, 'selectedNodeId:', this.selectedNodeId);
        this.showLoading();

        try {
            let url = `/api/topology/detailed?page=${this.currentPage}&limit=${this.pageSize}`;
            
            // 添加节点ID参数
            if (this.selectedNodeId) {
                url += `&node_id=${this.selectedNodeId}`;
            }
            
            if (isSearch && this.currentSearchTerm) {
                url = `/api/topology/search?q=${encodeURIComponent(this.currentSearchTerm)}&page=${this.currentPage}&limit=${this.pageSize}`;
                if (this.selectedNodeId) {
                    url += `&node_id=${this.selectedNodeId}`;
                }
            }
            
            console.log('🌐 请求URL:', url);

            const response = await fetch(url);
            const data = await response.json();
            
            console.log('📝 API响应:', data);

            if (data.success) {
                if (isSearch) {
                    this.renderTopologyTable(data.data);
                    this.hideStatsPanel(); // 搜索时隐藏统计面板
                    this.topologyData = data.data; // 保存数据供图形视图使用
                    console.log('🔍 搜索数据保存:', this.topologyData);
                } else {
                    this.renderTopologyTable(data.data.topologies);
                    this.updateStatsPanel(data.data.statistics);
                    this.topologyData = data.data.topologies; // 保存数据供图形视图使用
                    console.log('📊 拓扑数据保存:', this.topologyData);
                }
                this.renderPagination('topology', data.total, data.page, data.limit);
                
                // 如果当前是图形视图，更新图形
                if (this.currentView === 'diagram') {
                    console.log('🗺️ 当前是图形视图，更新图形');
                    this.drawNetworkDiagram();
                }
            } else {
                console.error('❌ API返回错误:', data.message);
                this.showMessage('加载网络拓扑数据失败: ' + data.message, 'error');
            }
        } catch (error) {
            console.error('❌ 请求失败:', error);
            this.showMessage('请求失败: ' + error.message, 'error');
        } finally {
            this.hideLoading();
        }
    }

    // 加载MAC-接口数据
    async loadMacInterfaceData() {
        this.showLoading();

        try {
            let url = `/api/mac-interfaces?page=${this.currentPage}&limit=${this.pageSize}`;
            
            // 添加节点ID参数
            if (this.selectedNodeId) {
                url += `&node_id=${this.selectedNodeId}`;
            }
            
            const response = await fetch(url);
            const data = await response.json();

            if (data.success) {
                this.renderMacInterfaceTable(data.data);
                this.renderPagination('mac', data.total, data.page, data.limit);
            } else {
                this.showMessage('加载MAC-接口数据失败: ' + data.message, 'error');
            }
        } catch (error) {
            this.showMessage('请求失败: ' + error.message, 'error');
        } finally {
            this.hideLoading();
        }
    }

    // 加载IP-接口数据
    async loadIPInterfaceData() {
        this.showLoading();

        try {
            let url = `/api/ip-interfaces?page=${this.currentPage}&limit=${this.pageSize}`;
            
            // 添加节点ID参数
            if (this.selectedNodeId) {
                url += `&node_id=${this.selectedNodeId}`;
            }
            
            const response = await fetch(url);
            const data = await response.json();

            if (data.success) {
                this.renderIPInterfaceTable(data.data);
                this.renderPagination('ip', data.total, data.page, data.limit);
            } else {
                this.showMessage('加载IP-接口数据失败: ' + data.message, 'error');
            }
        } catch (error) {
            this.showMessage('请求失败: ' + error.message, 'error');
        } finally {
            this.hideLoading();
        }
    }

    // 渲染网络拓扑表格
    renderTopologyTable(data) {
        const tbody = document.getElementById('topologyTableBody');
        
        if (!data || data.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="7" class="empty-state">
                        <i class="fas fa-inbox"></i>
                        <h3>暂无数据</h3>
                        <p>没有找到网络拓扑数据，请检查交换机配置和网络连接</p>
                    </td>
                </tr>
            `;
            return;
        }

        tbody.innerHTML = data.map(item => `
            <tr>
                <td><strong>${item.access_switch_ip || '-'}</strong></td>
                <td><span class="interface-badge">${item.access_interface || '-'}</span></td>
                <td><code class="mac-address">${item.mac_address || '-'}</code></td>
                <td><span class="ip-address">${item.terminal_ip || '-'}</span></td>
                <td><span class="vlan-badge">${item.vlan_id || '-'}</span></td>
                <td><small>${this.formatDateTime(item.updated_at)}</small></td>
                <td>
                    <details class="gateway-details">
                        <summary>查看网关信息</summary>
                        <div class="gateway-info">
                            <p><strong>网关IP:</strong> ${item.gateway_switch_ip || '-'}</p>
                            <p><strong>网关接口:</strong> ${item.gateway_interface || '-'}</p>
                        </div>
                    </details>
                </td>
            </tr>
        `).join('');
    }

    // 渲染MAC-接口表格
    renderMacInterfaceTable(data) {
        const tbody = document.getElementById('macTableBody');
        
        if (!data || data.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="6" class="empty-state">
                        <i class="fas fa-inbox"></i>
                        <h3>暂无数据</h3>
                        <p>没有找到MAC-接口数据</p>
                    </td>
                </tr>
            `;
            return;
        }

        tbody.innerHTML = data.map(item => `
            <tr>
                <td>${item.switch_ip || '-'}</td>
                <td>${item.interface_name || '-'}</td>
                <td>${item.interface_index || '-'}</td>
                <td>${item.mac_address || '-'}</td>
                <td>${item.vlan_id || '-'}</td>
                <td>${this.formatDateTime(item.updated_at)}</td>
            </tr>
        `).join('');
    }

    // 渲染IP-接口表格
    renderIPInterfaceTable(data) {
        const tbody = document.getElementById('ipTableBody');
        
        if (!data || data.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="6" class="empty-state">
                        <i class="fas fa-inbox"></i>
                        <h3>暂无数据</h3>
                        <p>没有找到IP-接口数据</p>
                    </td>
                </tr>
            `;
            return;
        }

        tbody.innerHTML = data.map(item => `
            <tr>
                <td>${item.gateway_ip || '-'}</td>
                <td>${item.interface_name || '-'}</td>
                <td>${item.interface_index || '-'}</td>
                <td>${item.terminal_ip || '-'}</td>
                <td>${item.mac_address || '-'}</td>
                <td>${this.formatDateTime(item.updated_at)}</td>
            </tr>
        `).join('');
    }

    // 渲染分页控件
    renderPagination(type, total, currentPage, pageSize) {
        const totalPages = Math.ceil(total / pageSize);
        const paginationId = type + 'Pagination';
        const pagination = document.getElementById(paginationId);

        if (totalPages <= 1) {
            pagination.innerHTML = '';
            return;
        }

        let html = `
            <button ${currentPage <= 1 ? 'disabled' : ''} onclick="app.goToPage(${currentPage - 1})">
                <i class="fas fa-chevron-left"></i> 上一页
            </button>
        `;

        // 显示页码
        const startPage = Math.max(1, currentPage - 2);
        const endPage = Math.min(totalPages, currentPage + 2);

        if (startPage > 1) {
            html += `<button onclick="app.goToPage(1)">1</button>`;
            if (startPage > 2) {
                html += `<span>...</span>`;
            }
        }

        for (let i = startPage; i <= endPage; i++) {
            html += `<button ${i === currentPage ? 'class="active"' : ''} onclick="app.goToPage(${i})">${i}</button>`;
        }

        if (endPage < totalPages) {
            if (endPage < totalPages - 1) {
                html += `<span>...</span>`;
            }
            html += `<button onclick="app.goToPage(${totalPages})">${totalPages}</button>`;
        }

        html += `
            <button ${currentPage >= totalPages ? 'disabled' : ''} onclick="app.goToPage(${currentPage + 1})">
                下一页 <i class="fas fa-chevron-right"></i>
            </button>
        `;

        html += `<div class="pagination-info">共 ${total} 条记录</div>`;

        pagination.innerHTML = html;
    }

    // 跳转到指定页面
    goToPage(page) {
        this.currentPage = page;
        
        switch (this.currentTab) {
            case 'topology':
                this.loadTopologyData(!!this.currentSearchTerm);
                break;
            case 'mac-interfaces':
                this.loadMacInterfaceData();
                break;
            case 'ip-interfaces':
                this.loadIPInterfaceData();
                break;
        }
    }

    // 显示系统状态
    async showStatus() {
        try {
            const response = await fetch('/api/status');
            const data = await response.json();

            if (data.success) {
                const status = data.data;
                const statusHtml = `
                    <div class="status-item">
                        <span class="status-label">运行状态:</span>
                        <span class="status-value ${status.running ? 'status-running' : 'status-stopped'}">
                            ${status.running ? '运行中' : '已停止'}
                        </span>
                    </div>
                    <div class="status-item">
                        <span class="status-label">接入交换机数量:</span>
                        <span class="status-value">${status.access_switches || 0} 台</span>
                    </div>
                    <div class="status-item">
                        <span class="status-label">网关交换机数量:</span>
                        <span class="status-value">${status.gateway_switches || 0} 台</span>
                    </div>
                    <div class="status-item">
                        <span class="status-label">接入交换机IP:</span>
                        <span class="status-value">${(status.access_switch_ips || []).join(', ') || '无'}</span>
                    </div>
                    <div class="status-item">
                        <span class="status-label">网关交换机IP:</span>
                        <span class="status-value">${(status.gateway_switch_ips || []).join(', ') || '无'}</span>
                    </div>
                `;

                document.getElementById('statusContent').innerHTML = statusHtml;
                document.getElementById('statusModal').style.display = 'block';
            } else {
                this.showMessage('获取状态信息失败: ' + data.message, 'error');
            }
        } catch (error) {
            this.showMessage('请求失败: ' + error.message, 'error');
        }
    }

    // 触发数据收集
    async triggerCollection() {
        try {
            const response = await fetch('/api/collect', { method: 'POST' });
            const data = await response.json();

            if (data.success) {
                this.showMessage('数据收集已触发', 'success');
                
                // 延迟刷新数据
                setTimeout(() => {
                    if (this.currentTab === 'topology') {
                        this.loadTopologyData(!!this.currentSearchTerm);
                    }
                }, 2000);
            } else {
                this.showMessage('触发数据收集失败: ' + data.message, 'error');
            }
        } catch (error) {
            this.showMessage('请求失败: ' + error.message, 'error');
        }
    }

    // 重新加载配置
    async reloadConfig() {
        try {
            const response = await fetch('/api/reload', { method: 'POST' });
            const data = await response.json();

            if (data.success) {
                this.showMessage('配置已重新加载', 'success');
            } else {
                this.showMessage('重新加载配置失败: ' + data.message, 'error');
            }
        } catch (error) {
            this.showMessage('请求失败: ' + error.message, 'error');
        }
    }

    // 关闭模态框
    closeModal() {
        document.getElementById('statusModal').style.display = 'none';
    }

    // 显示加载状态
    showLoading() {
        document.getElementById('loadingOverlay').style.display = 'block';
    }

    // 隐藏加载状态
    hideLoading() {
        document.getElementById('loadingOverlay').style.display = 'none';
    }

    // 显示消息
    showMessage(message, type = 'info') {
        const container = document.getElementById('messageContainer');
        const messageDiv = document.createElement('div');
        messageDiv.className = `message message-${type}`;
        messageDiv.textContent = message;

        container.appendChild(messageDiv);

        // 3秒后自动移除消息
        setTimeout(() => {
            if (messageDiv.parentNode) {
                messageDiv.parentNode.removeChild(messageDiv);
            }
        }, 3000);
    }

    // 格式化日期时间
    formatDateTime(dateString) {
        if (!dateString) return '-';
        
        const date = new Date(dateString);
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        const seconds = String(date.getSeconds()).padStart(2, '0');
        
        return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    }

    // 更新统计面板
    updateStatsPanel(statistics) {
        document.getElementById('totalConnections').textContent = statistics.total_connections || 0;
        document.getElementById('accessSwitches').textContent = statistics.access_switches || 0;
        document.getElementById('uniqueMacs').textContent = statistics.unique_macs || 0;
        document.getElementById('uniqueIPs').textContent = statistics.unique_ips || 0;
        
        // 显示统计面板
        document.getElementById('statsPanel').style.display = 'grid';
    }

    // 隐藏统计面板
    hideStatsPanel() {
        document.getElementById('statsPanel').style.display = 'none';
    }

    // 切换视图模式
    switchView(viewType) {
        console.log('🔄 切换视图模式:', viewType);
        
        if (viewType === 'diagram') {
            // 直接跳转到独立的网络拓扑图页面
            console.log('🗺️ 跳转到独立网络拓扑图页面');
            window.open('/topology', '_blank');
            return;
        }
        
        this.currentView = viewType;
        
        // 更新按钮状态
        document.getElementById('tableViewBtn').classList.toggle('active', viewType === 'table');
        document.getElementById('diagramViewBtn').classList.toggle('active', viewType === 'diagram');
        
        // 切换视图
        document.getElementById('tableView').style.display = viewType === 'table' ? 'block' : 'none';
        document.getElementById('diagramView').style.display = viewType === 'diagram' ? 'block' : 'none';
    }

    // 绘制网络拓扑图
    async renderTopologyDiagram() {
        if (!this.topologyData || this.topologyData.length === 0) {
            // 如果没有数据，重新加载
            await this.loadTopologyDataForDiagram();
        }
        
        this.drawNetworkDiagram();
    }

    // 为图形视图加载拓扑数据
    async loadTopologyDataForDiagram() {
        try {
            const response = await fetch('/api/topology/detailed?page=1&limit=100'); // 获取前100条记录
            const data = await response.json();
            
            if (data.success) {
                this.topologyData = data.data.topologies || [];
            }
        } catch (error) {
            console.error('加载拓扑数据失败:', error);
            this.topologyData = [];
        }
    }

    // 绘制网络图
    drawNetworkDiagram() {
        const container = document.getElementById('topologyContainer');
        console.log('🔍 开始绘制网络图, container:', container);
        container.innerHTML = ''; // 清空容器
        
        // 创建缩放和平移容器
        const zoomContainer = document.createElement('div');
        zoomContainer.className = 'zoom-container';
        zoomContainer.id = 'zoomContainer';
        
        // 创建内容容器
        const contentContainer = document.createElement('div');
        contentContainer.className = 'content-container';
        contentContainer.id = 'contentContainer';
        
        zoomContainer.appendChild(contentContainer);
        container.appendChild(zoomContainer);
        
        // 初始化缩放和平移
        this.updateTransform();
        
        console.log('📊 拓扑数据:', this.topologyData);
        
        if (!this.topologyData || this.topologyData.length === 0) {
            console.warn('⚠️ 没有拓扑数据');
            contentContainer.innerHTML = `
                <div style="text-align: center; padding: 100px; color: #666;">
                    <i class="fas fa-network-wired" style="font-size: 4rem; margin-bottom: 20px;"></i>
                    <h3>暂无网络拓扑数据</h3>
                    <p>请检查网络连接和设备配置</p>
                    <button onclick="app.triggerCollection()" style="margin-top: 10px; padding: 8px 16px; background: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer;">
                        手动收集数据
                    </button>
                </div>
            `;
            return;
        }
        
        console.log('🏠 整理网络数据...');
        // 整理数据结构
        const networkStructure = this.organizeNetworkData();
        console.log('🏠 网络结构:', networkStructure);
        
        // 绘制设备和连接
        console.log('🗺️ 绘制设备...');
        this.drawDevices(contentContainer, networkStructure);
        console.log('🔗 绘制连接线...');
        this.drawConnections(contentContainer, networkStructure);
        
        // 添加事件监听
        this.setupDiagramInteractions();
        
        // 设置缩放和平移事件
        this.setupZoomAndPan();
        
        console.log('✅ 网络图绘制完成!');
    }

    // 整理网络数据结构
    organizeNetworkData() {
        const gateways = new Map();
        const switches = new Map();
        const terminals = new Map();
        const connections = [];
        
        // 验证IP地址的函数
        function isValidIP(ip) {
            if (!ip) return false;
            const parts = ip.split('.');
            if (parts.length !== 4) return false;
            for (let part of parts) {
                const num = parseInt(part, 10);
                if (isNaN(num) || num < 0 || num > 255) return false;
            }
            return true;
        }
        
        this.topologyData.forEach(item => {
            // 过滤无效的IP地址
            if (!isValidIP(item.terminal_ip)) {
                console.warn('⚠️ 过滤无效IP:', item.terminal_ip);
                return; // 跳过无效数据
            }
            
            // 网关设备
            if (!gateways.has(item.gateway_switch_ip)) {
                gateways.set(item.gateway_switch_ip, {
                    ip: item.gateway_switch_ip,
                    type: 'gateway',
                    interfaces: new Set()
                });
            }
            gateways.get(item.gateway_switch_ip).interfaces.add(item.gateway_interface);
            
            // 接入交换机
            if (!switches.has(item.access_switch_ip)) {
                switches.set(item.access_switch_ip, {
                    ip: item.access_switch_ip,
                    type: 'switch',
                    interfaces: new Set(),
                    terminals: []
                });
            }
            const switchData = switches.get(item.access_switch_ip);
            switchData.interfaces.add(item.access_interface);
            
            // 终端设备（包含接口信息）
            const terminalKey = `${item.terminal_ip}_${item.mac_address}`;
            if (!terminals.has(terminalKey)) {
                const terminal = {
                    ip: item.terminal_ip,
                    mac: item.mac_address,
                    type: 'terminal',
                    connectedSwitch: item.access_switch_ip,
                    interface: item.access_interface, // 添加接口信息
                    switchInterface: item.access_interface // 交换机接口
                };
                terminals.set(terminalKey, terminal);
                switchData.terminals.push(terminal);
            }
            
            // 连接关系
            connections.push({
                from: item.gateway_switch_ip,
                to: item.access_switch_ip,
                fromType: 'gateway',
                toType: 'switch'
            });
            
            connections.push({
                from: item.access_switch_ip,
                to: item.terminal_ip,
                fromType: 'switch',
                toType: 'terminal',
                mac: item.mac_address,
                interface: item.access_interface // 添加接口信息
            });
        });
        
        const result = {
            gateways: Array.from(gateways.values()),
            switches: Array.from(switches.values()),
            terminals: Array.from(terminals.values()),
            connections: connections
        };
        
        console.log('🏠 整理后的网络结构:', result);
        return result;
    }

    // 绘制设备
    drawDevices(container, networkStructure) {
        const containerWidth = container.offsetWidth || 800;
        const containerHeight = container.offsetHeight || 600;
        
        // 网关设备在顶部中央
        networkStructure.gateways.forEach((gateway, index) => {
            const x = containerWidth / 2 - 40;
            const y = 50;
            this.createDeviceNode(container, gateway, x, y, 'core');
        });
        
        // 接入交换机在中间层
        const switchCount = networkStructure.switches.length;
        networkStructure.switches.forEach((switchDevice, index) => {
            const spacing = Math.min(200, containerWidth / (switchCount + 1));
            const x = (containerWidth / (switchCount + 1)) * (index + 1) - 32;
            const y = 250;
            this.createDeviceNode(container, switchDevice, x, y, 'switch');
        });
        
        // 终端设备在底部 - 改进布局算法避免重叠
        const terminalCount = networkStructure.terminals.length;
        const maxColumns = Math.ceil(Math.sqrt(terminalCount)); // 计算最佳列数
        const columnWidth = Math.max(120, containerWidth / maxColumns); // 每列最小120px
        
        networkStructure.terminals.forEach((terminal, index) => {
            const row = Math.floor(index / maxColumns);
            const col = index % maxColumns;
            const x = col * columnWidth + 50;
            const y = 450 + row * 100; // 每行间距100px
            this.createDeviceNode(container, terminal, x, y, 'pc');
        });
    }

    // 创建设备节点
    createDeviceNode(container, device, x, y, deviceType) {
        const node = document.createElement('div');
        node.className = 'device-node';
        node.style.left = x + 'px';
        node.style.top = y + 'px';
        node.dataset.deviceIp = device.ip;
        node.dataset.deviceType = deviceType;
        
        const icon = document.createElement('div');
        icon.className = `device-icon ${deviceType}`;
        
        // 为PC设备添加接口信息覆盖层
        if (deviceType === 'pc' && device.interface) {
            const interfaceLabel = document.createElement('div');
            interfaceLabel.className = 'interface-overlay';
            interfaceLabel.textContent = device.interface;
            icon.appendChild(interfaceLabel);
        }
        
        const label = document.createElement('div');
        label.className = 'device-label';
        
        // 根据设备类型显示不同的标签信息
        if (deviceType === 'pc') {
            label.innerHTML = `
                <div class="device-ip">${device.ip || 'Unknown'}</div>
                ${device.interface ? `<div class="device-interface">接口: ${device.interface}</div>` : ''}
                ${device.mac ? `<div class="device-mac">MAC: ${device.mac.substring(0, 8)}...</div>` : ''}
            `;
        } else {
            label.textContent = device.ip || device.mac || 'Unknown';
        }
        
        node.appendChild(icon);
        node.appendChild(label);
        container.appendChild(node);
        
        // 添加悬停事件
        this.addDeviceTooltip(node, device, deviceType);
    }

    // 绘制连接线
    drawConnections(container, networkStructure) {
        // 简化版本：只绘制垂直连接线
        const devices = container.querySelectorAll('.device-node');
        const gateway = Array.from(devices).find(d => d.dataset.deviceType === 'core');
        const switches = Array.from(devices).filter(d => d.dataset.deviceType === 'switch');
        const terminals = Array.from(devices).filter(d => d.dataset.deviceType === 'pc');
        
        if (gateway) {
            const gatewayRect = gateway.getBoundingClientRect();
            const containerRect = container.getBoundingClientRect();
            const gatewayX = gatewayRect.left - containerRect.left + gatewayRect.width / 2;
            const gatewayY = gatewayRect.top - containerRect.top + gatewayRect.height;
            
            // 连接网关到交换机
            switches.forEach(switchDevice => {
                const switchRect = switchDevice.getBoundingClientRect();
                const switchX = switchRect.left - containerRect.left + switchRect.width / 2;
                const switchY = switchRect.top - containerRect.top;
                
                this.createConnectionLine(container, gatewayX, gatewayY, switchX, switchY);
            });
        }
        
        // 连接交换机到终端
        switches.forEach(switchDevice => {
            const switchRect = switchDevice.getBoundingClientRect();
            const containerRect = container.getBoundingClientRect();
            const switchX = switchRect.left - containerRect.left + switchRect.width / 2;
            const switchY = switchRect.top - containerRect.top + switchRect.height;
            
            // 找到连接到该交换机的终端
            const connectedTerminals = terminals.filter(terminal => {
                const terminalData = this.topologyData.find(t => t.terminal_ip === terminal.dataset.deviceIp);
                return terminalData && terminalData.access_switch_ip === switchDevice.dataset.deviceIp;
            });
            
            connectedTerminals.forEach(terminal => {
                const terminalRect = terminal.getBoundingClientRect();
                const terminalX = terminalRect.left - containerRect.left + terminalRect.width / 2;
                const terminalY = terminalRect.top - containerRect.top;
                
                this.createConnectionLine(container, switchX, switchY, terminalX, terminalY);
            });
        });
    }

    // 创建连接线
    createConnectionLine(container, x1, y1, x2, y2) {
        const line = document.createElement('div');
        line.className = 'connection-line';
        
        if (Math.abs(x1 - x2) < Math.abs(y1 - y2)) {
            // 垂直线
            line.classList.add('vertical');
            line.style.left = Math.min(x1, x2) + 'px';
            line.style.top = Math.min(y1, y2) + 'px';
            line.style.height = Math.abs(y2 - y1) + 'px';
        } else {
            // 水平线
            line.classList.add('horizontal');
            line.style.left = Math.min(x1, x2) + 'px';
            line.style.top = Math.min(y1, y2) + 'px';
            line.style.width = Math.abs(x2 - x1) + 'px';
        }
        
        container.appendChild(line);
    }

    // 添加设备提示信息
    addDeviceTooltip(node, device, deviceType) {
        node.addEventListener('mouseenter', (e) => {
            const tooltip = document.getElementById('deviceTooltip');
            let content = '';
            
            switch (deviceType) {
                case 'core':
                    content = `
                        <strong>网关设备</strong><br>
                        IP: ${device.ip}<br>
                        接口数: ${device.interfaces ? device.interfaces.size : 0}
                    `;
                    break;
                case 'switch':
                    content = `
                        <strong>接入交换机</strong><br>
                        IP: ${device.ip}<br>
                        接口数: ${device.interfaces ? device.interfaces.size : 0}<br>
                        终端数: ${device.terminals ? device.terminals.length : 0}
                    `;
                    break;
                case 'pc':
                    content = `
                        <strong>终端设备</strong><br>
                        IP: ${device.ip}<br>
                        MAC: ${device.mac}<br>
                        ${
                            device.interface 
                                ? `连接接口: ${device.interface}<br>` 
                                : ''
                        }
                        ${
                            device.connectedSwitch 
                                ? `所属交换机: ${device.connectedSwitch}` 
                                : ''
                        }
                    `;
                    break;
            }
            
            tooltip.innerHTML = content;
            tooltip.style.left = e.pageX + 10 + 'px';
            tooltip.style.top = e.pageY - 10 + 'px';
            tooltip.classList.add('show');
        });
        
        node.addEventListener('mouseleave', () => {
            const tooltip = document.getElementById('deviceTooltip');
            tooltip.classList.remove('show');
        });
    }

    // 设置图表交互
    setupDiagramInteractions() {
        // 设备点击事件
        document.querySelectorAll('.device-node').forEach(node => {
            node.addEventListener('click', (e) => {
                const deviceIp = e.currentTarget.dataset.deviceIp;
                const deviceType = e.currentTarget.dataset.deviceType;
                
                // 可以添加设备详情查看功能
                console.log(`点击了${deviceType}设备: ${deviceIp}`);
            });
        });
    }
    
    // 设置缩放和平移功能
    setupZoomAndPan() {
        const container = document.getElementById('topologyContainer');
        const zoomContainer = document.getElementById('zoomContainer');
        
        if (!container || !zoomContainer) return;
        
        // 鼠标滚轮缩放
        container.addEventListener('wheel', (e) => {
            e.preventDefault();
            
            const rect = container.getBoundingClientRect();
            const mouseX = e.clientX - rect.left;
            const mouseY = e.clientY - rect.top;
            
            const delta = e.deltaY > 0 ? 0.9 : 1.1;
            const newZoom = Math.max(this.minZoom, Math.min(this.maxZoom, this.zoomLevel * delta));
            
            if (newZoom !== this.zoomLevel) {
                // 计算缩放中心点
                const zoomCenterX = (mouseX - this.panX) / this.zoomLevel;
                const zoomCenterY = (mouseY - this.panY) / this.zoomLevel;
                
                this.zoomLevel = newZoom;
                
                // 调整平移以保持缩放中心点不变
                this.panX = mouseX - zoomCenterX * this.zoomLevel;
                this.panY = mouseY - zoomCenterY * this.zoomLevel;
                
                this.updateTransform();
            }
        });
        
        // 鼠标拖拽平移
        container.addEventListener('mousedown', (e) => {
            if (e.button === 0) { // 左键
                this.isDragging = true;
                this.lastMouseX = e.clientX;
                this.lastMouseY = e.clientY;
                container.style.cursor = 'grabbing';
                e.preventDefault();
            }
        });
        
        document.addEventListener('mousemove', (e) => {
            if (this.isDragging) {
                const deltaX = e.clientX - this.lastMouseX;
                const deltaY = e.clientY - this.lastMouseY;
                
                this.panX += deltaX;
                this.panY += deltaY;
                
                this.lastMouseX = e.clientX;
                this.lastMouseY = e.clientY;
                
                this.updateTransform();
                e.preventDefault();
            }
        });
        
        document.addEventListener('mouseup', (e) => {
            if (this.isDragging) {
                this.isDragging = false;
                container.style.cursor = 'grab';
            }
        });
        
        // 添加缩放控制按钮事件
        this.setupZoomControls();
    }
    
    // 设置缩放控制按钮
    setupZoomControls() {
        const zoomInBtn = document.getElementById('zoomInBtn');
        const zoomOutBtn = document.getElementById('zoomOutBtn');
        const resetZoomBtn = document.getElementById('resetZoomBtn');
        
        if (zoomInBtn) {
            zoomInBtn.addEventListener('click', () => {
                this.zoomIn();
            });
        }
        
        if (zoomOutBtn) {
            zoomOutBtn.addEventListener('click', () => {
                this.zoomOut();
            });
        }
        
        if (resetZoomBtn) {
            resetZoomBtn.addEventListener('click', () => {
                this.resetZoom();
            });
        }
    }
    
    // 放大
    zoomIn() {
        const newZoom = Math.min(this.maxZoom, this.zoomLevel * 1.2);
        if (newZoom !== this.zoomLevel) {
            this.zoomLevel = newZoom;
            this.updateTransform();
        }
    }
    
    // 缩小
    zoomOut() {
        const newZoom = Math.max(this.minZoom, this.zoomLevel * 0.8);
        if (newZoom !== this.zoomLevel) {
            this.zoomLevel = newZoom;
            this.updateTransform();
        }
    }
    
    // 重置缩放
    resetZoom() {
        this.zoomLevel = 1;
        this.panX = 0;
        this.panY = 0;
        this.updateTransform();
    }
    
    // 更新变换
    updateTransform() {
        const contentContainer = document.getElementById('contentContainer');
        if (contentContainer) {
            contentContainer.style.transform = `translate(${this.panX}px, ${this.panY}px) scale(${this.zoomLevel})`;
        }
    }
}

// 初始化应用程序
const app = new NetworkMonitorApp();