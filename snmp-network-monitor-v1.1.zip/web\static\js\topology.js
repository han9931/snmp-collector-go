class TopologyViewer {
    constructor() {
        this.zoomLevel = 1;
        this.panX = 0;
        this.panY = 0;
        this.topologyData = [];
        this.isDragging = false;
        this.startX = 0;
        this.startY = 0;
        this.minZoom = 0.2;
        this.maxZoom = 3.0;
        
        this.init();
    }

    async init() {
        console.log('🚀 初始化网络拓扑查看器');
        this.setupEventListeners();
        await this.loadTopologyData();
    }

    setupEventListeners() {
        const container = document.getElementById('zoomContainer');
        
        // 鼠标滚轮缩放
        container.addEventListener('wheel', (e) => {
            e.preventDefault();
            const delta = e.deltaY > 0 ? -0.1 : 0.1;
            this.zoom(this.zoomLevel + delta);
        });

        // 鼠标拖拽平移
        container.addEventListener('mousedown', (e) => {
            this.isDragging = true;
            this.startX = e.clientX - this.panX;
            this.startY = e.clientY - this.panY;
            container.style.cursor = 'grabbing';
        });

        document.addEventListener('mousemove', (e) => {
            if (this.isDragging) {
                this.panX = e.clientX - this.startX;
                this.panY = e.clientY - this.startY;
                this.updateTransform();
            }
        });

        document.addEventListener('mouseup', () => {
            this.isDragging = false;
            container.style.cursor = 'grab';
        });

        // 防止选择文本
        container.addEventListener('selectstart', (e) => e.preventDefault());
    }

    async loadTopologyData() {
        this.showLoading();
        
        try {
            console.log('📡 加载网络拓扑数据...');
            
            // 从URL参数中获取节点ID
            const urlParams = new URLSearchParams(window.location.search);
            const nodeId = urlParams.get('node_id');
            
            let url = '/api/topology/detailed?page=1&limit=1000';
            if (nodeId) {
                url += `&node_id=${nodeId}`;
                console.log('🏷️ 使用节点ID:', nodeId);
            }
            
            const response = await fetch(url);
            const data = await response.json();
            
            if (data.success) {
                this.topologyData = data.data.topologies || [];
                console.log('✅ 数据加载成功，记录数:', this.topologyData.length);
                
                // 更新统计信息
                if (data.data.statistics) {
                    this.updateStatsPanel(data.data.statistics);
                }
                
                // 绘制拓扑图
                this.drawNetworkDiagram();
            } else {
                throw new Error(data.message || '数据加载失败');
            }
        } catch (error) {
            console.error('❌ 加载数据失败:', error);
            this.showError('加载拓扑数据失败: ' + error.message);
            this.showEmptyState();
        } finally {
            this.hideLoading();
        }
    }

    drawNetworkDiagram() {
        const container = document.getElementById('contentContainer');
        console.log('🎨 开始绘制网络拓扑图');
        container.innerHTML = '';
        
        if (!this.topologyData || this.topologyData.length === 0) {
            this.showEmptyState();
            return;
        }
        
        // 整理网络数据
        const networkStructure = this.organizeNetworkData();
        console.log('🏗️ 网络结构:', networkStructure);
        
        // 绘制设备和连接
        this.drawDevices(container, networkStructure);
        this.drawConnections(container, networkStructure);
        
        console.log('✅ 拓扑图绘制完成');
    }

    organizeNetworkData() {
        const gateways = new Map();
        const switches = new Map();
        const terminals = new Map();
        
        // 验证IP地址
        const isValidIP = (ip) => {
            if (!ip) return false;
            const parts = ip.split('.');
            if (parts.length !== 4) return false;
            return parts.every(part => {
                const num = parseInt(part, 10);
                return !isNaN(num) && num >= 0 && num <= 255;
            });
        };
        
        this.topologyData.forEach(item => {
            if (!isValidIP(item.terminal_ip)) {
                console.warn('⚠️ 过滤无效IP:', item.terminal_ip);
                return;
            }
            
            // 网关设备
            if (!gateways.has(item.gateway_switch_ip)) {
                gateways.set(item.gateway_switch_ip, {
                    ip: item.gateway_switch_ip,
                    type: 'gateway',
                    interfaces: new Set()
                });
            }
            gateways.get(item.gateway_switch_ip).interfaces.add(item.gateway_interface);
            
            // 接入交换机
            if (!switches.has(item.access_switch_ip)) {
                switches.set(item.access_switch_ip, {
                    ip: item.access_switch_ip,
                    type: 'switch',
                    interfaces: new Set(),
                    terminals: []
                });
            }
            const switchData = switches.get(item.access_switch_ip);
            switchData.interfaces.add(item.access_interface);
            
            // 终端设备
            const terminalKey = `${item.terminal_ip}_${item.mac_address}`;
            if (!terminals.has(terminalKey)) {
                const terminal = {
                    ip: item.terminal_ip,
                    mac: item.mac_address,
                    type: 'terminal',
                    connectedSwitch: item.access_switch_ip,
                    interface: item.access_interface
                };
                terminals.set(terminalKey, terminal);
                switchData.terminals.push(terminal);
            }
        });
        
        return {
            gateways: Array.from(gateways.values()),
            switches: Array.from(switches.values()),
            terminals: Array.from(terminals.values())
        };
    }

    drawDevices(container, networkStructure) {
        const containerWidth = 1200;
        const containerHeight = 800;
        
        // 网关设备在顶部
        networkStructure.gateways.forEach((gateway, index) => {
            const x = containerWidth / 2 - 40;
            const y = 80;
            this.createDeviceNode(container, gateway, x, y, 'core');
        });
        
        // 接入交换机在中间层
        const switchCount = networkStructure.switches.length;
        if (switchCount > 0) {
            networkStructure.switches.forEach((switchDevice, index) => {
                const x = (containerWidth / (switchCount + 1)) * (index + 1) - 40;
                const y = 300;
                this.createDeviceNode(container, switchDevice, x, y, 'switch');
            });
        }
        
        // 终端设备在底部 - 网格布局
        const terminalCount = networkStructure.terminals.length;
        if (terminalCount > 0) {
            const maxColumns = Math.min(8, Math.ceil(Math.sqrt(terminalCount)));
            const columnWidth = (containerWidth - 100) / maxColumns;
            
            networkStructure.terminals.forEach((terminal, index) => {
                const row = Math.floor(index / maxColumns);
                const col = index % maxColumns;
                const x = col * columnWidth + 60;
                const y = 520 + row * 120;
                this.createDeviceNode(container, terminal, x, y, 'pc');
            });
        }
    }

    createDeviceNode(container, device, x, y, deviceType) {
        const node = document.createElement('div');
        node.className = 'device-node';
        node.style.left = x + 'px';
        node.style.top = y + 'px';
        node.dataset.deviceIp = device.ip;
        node.dataset.deviceType = deviceType;
        
        const icon = document.createElement('div');
        icon.className = `device-icon ${deviceType}`;
        
        // 设备图标
        const iconSymbol = document.createElement('i');
        iconSymbol.className = deviceType === 'core' ? 'fas fa-server' : 
                             deviceType === 'switch' ? 'fas fa-network-wired' : 'fas fa-desktop';
        icon.appendChild(iconSymbol);
        
        // PC设备添加接口信息覆盖层
        if (deviceType === 'pc' && device.interface) {
            const interfaceLabel = document.createElement('div');
            interfaceLabel.className = 'interface-overlay';
            interfaceLabel.textContent = device.interface.length > 6 ? 
                device.interface.substring(0, 6) + '...' : device.interface;
            icon.appendChild(interfaceLabel);
        }
        
        const label = document.createElement('div');
        label.className = 'device-label';
        
        // 根据设备类型显示不同信息
        if (deviceType === 'pc') {
            label.innerHTML = `
                <div class="device-ip">${device.ip}</div>
                ${device.interface ? `<div class="device-interface">${device.interface}</div>` : ''}
                ${device.mac ? `<div class="device-mac">${device.mac.substring(0, 12)}...</div>` : ''}
            `;
        } else {
            const deviceName = deviceType === 'core' ? '核心交换机' : '接入交换机';
            label.innerHTML = `
                <div style="font-weight: bold; margin-bottom: 3px;">${deviceName}</div>
                <div class="device-ip">${device.ip}</div>
            `;
        }
        
        node.appendChild(icon);
        node.appendChild(label);
        container.appendChild(node);
        
        // 添加悬停提示
        this.addDeviceTooltip(node, device, deviceType);
    }

    drawConnections(container, networkStructure) {
        // 延迟绘制连接线，确保设备节点已渲染
        setTimeout(() => {
            const devices = container.querySelectorAll('.device-node');
            const gateway = Array.from(devices).find(d => d.dataset.deviceType === 'core');
            const switches = Array.from(devices).filter(d => d.dataset.deviceType === 'switch');
            
            if (gateway) {
                const gatewayRect = this.getElementPosition(gateway);
                
                // 连接网关到交换机
                switches.forEach(switchDevice => {
                    const switchRect = this.getElementPosition(switchDevice);
                    this.createConnectionLine(container, 
                        gatewayRect.centerX, gatewayRect.bottom,
                        switchRect.centerX, switchRect.top
                    );
                });
                
                // 连接交换机到终端
                switches.forEach(switchDevice => {
                    const switchRect = this.getElementPosition(switchDevice);
                    const switchIP = switchDevice.dataset.deviceIp;
                    
                    const connectedTerminals = Array.from(devices).filter(d => {
                        if (d.dataset.deviceType !== 'pc') return false;
                        const terminalData = this.topologyData.find(t => 
                            t.terminal_ip === d.dataset.deviceIp && 
                            t.access_switch_ip === switchIP
                        );
                        return !!terminalData;
                    });
                    
                    connectedTerminals.forEach(terminal => {
                        const terminalRect = this.getElementPosition(terminal);
                        this.createConnectionLine(container,
                            switchRect.centerX, switchRect.bottom,
                            terminalRect.centerX, terminalRect.top
                        );
                    });
                });
            }
        }, 100);
    }

    getElementPosition(element) {
        const rect = element.getBoundingClientRect();
        const container = document.getElementById('contentContainer');
        const containerRect = container.getBoundingClientRect();
        
        return {
            left: rect.left - containerRect.left,
            top: rect.top - containerRect.top,
            right: rect.right - containerRect.left,
            bottom: rect.bottom - containerRect.top,
            centerX: rect.left - containerRect.left + rect.width / 2,
            centerY: rect.top - containerRect.top + rect.height / 2,
            width: rect.width,
            height: rect.height
        };
    }

    createConnectionLine(container, x1, y1, x2, y2) {
        const line = document.createElement('div');
        line.className = 'connection-line';
        
        const deltaX = x2 - x1;
        const deltaY = y2 - y1;
        const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
        const angle = Math.atan2(deltaY, deltaX) * 180 / Math.PI;
        
        line.style.width = distance + 'px';
        line.style.height = '3px';
        line.style.left = x1 + 'px';
        line.style.top = y1 + 'px';
        line.style.transform = `rotate(${angle}deg)`;
        line.style.transformOrigin = '0 0';
        
        container.appendChild(line);
    }

    addDeviceTooltip(node, device, deviceType) {
        const tooltip = document.getElementById('deviceTooltip');
        
        node.addEventListener('mouseenter', (e) => {
            let tooltipContent = '';
            
            if (deviceType === 'pc') {
                tooltipContent = `
                    <div><strong>终端设备</strong></div>
                    <div>IP地址: ${device.ip}</div>
                    <div>MAC地址: ${device.mac || 'N/A'}</div>
                    <div>接口: ${device.interface || 'N/A'}</div>
                    <div>连接交换机: ${device.connectedSwitch || 'N/A'}</div>
                `;
            } else if (deviceType === 'switch') {
                const terminalCount = device.terminals ? device.terminals.length : 0;
                tooltipContent = `
                    <div><strong>接入交换机</strong></div>
                    <div>IP地址: ${device.ip}</div>
                    <div>连接终端数: ${terminalCount}</div>
                    <div>接口数: ${device.interfaces ? device.interfaces.size : 0}</div>
                `;
            } else if (deviceType === 'core') {
                tooltipContent = `
                    <div><strong>核心交换机/网关</strong></div>
                    <div>IP地址: ${device.ip}</div>
                    <div>接口数: ${device.interfaces ? device.interfaces.size : 0}</div>
                `;
            }
            
            tooltip.innerHTML = tooltipContent;
            tooltip.classList.add('show');
            
            // 定位提示框
            const rect = node.getBoundingClientRect();
            tooltip.style.left = rect.right + 10 + 'px';
            tooltip.style.top = rect.top + 'px';
        });
        
        node.addEventListener('mouseleave', () => {
            tooltip.classList.remove('show');
        });
    }

    updateStatsPanel(statistics) {
        document.getElementById('totalConnections').textContent = statistics.total_connections || 0;
        document.getElementById('accessSwitches').textContent = statistics.access_switches || 0;
        document.getElementById('uniqueMacs').textContent = statistics.unique_macs || 0;
        document.getElementById('uniqueIPs').textContent = statistics.unique_ips || 0;
        
        // 显示统计面板
        document.getElementById('statsPanel').style.display = 'flex';
    }

    showEmptyState() {
        const container = document.getElementById('contentContainer');
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-network-wired"></i>
                <h3>暂无网络拓扑数据</h3>
                <p>请检查网络连接和设备配置，或点击刷新数据按钮重新获取</p>
                <button onclick="triggerCollection()" style="margin-top: 20px; padding: 10px 20px; background: #007bff; color: white; border: none; border-radius: 6px; cursor: pointer;">
                    <i class="fas fa-sync-alt"></i> 刷新数据
                </button>
            </div>
        `;
    }

    showLoading() {
        document.getElementById('loadingOverlay').style.display = 'flex';
    }

    hideLoading() {
        document.getElementById('loadingOverlay').style.display = 'none';
    }

    showError(message) {
        this.showMessage(message, 'error');
    }

    showMessage(message, type = 'info') {
        const container = document.getElementById('messageContainer');
        const messageDiv = document.createElement('div');
        messageDiv.className = `message message-${type}`;
        messageDiv.textContent = message;

        container.appendChild(messageDiv);

        // 3秒后自动移除消息
        setTimeout(() => {
            if (messageDiv.parentNode) {
                messageDiv.parentNode.removeChild(messageDiv);
            }
        }, 3000);
    }

    zoom(newZoomLevel) {
        this.zoomLevel = Math.max(this.minZoom, Math.min(this.maxZoom, newZoomLevel));
        this.updateTransform();
        this.updateZoomLevel();
    }

    updateTransform() {
        const container = document.getElementById('zoomContainer');
        container.style.transform = `translate(${this.panX}px, ${this.panY}px) scale(${this.zoomLevel})`;
    }

    updateZoomLevel() {
        document.getElementById('zoomLevel').textContent = Math.round(this.zoomLevel * 100) + '%';
    }

    resetZoom() {
        this.zoomLevel = 1;
        this.panX = 0;
        this.panY = 0;
        this.updateTransform();
        this.updateZoomLevel();
    }
}

// 全局函数
function zoomIn() {
    if (window.topologyViewer) {
        window.topologyViewer.zoom(window.topologyViewer.zoomLevel + 0.2);
    }
}

function zoomOut() {
    if (window.topologyViewer) {
        window.topologyViewer.zoom(window.topologyViewer.zoomLevel - 0.2);
    }
}

function resetZoom() {
    if (window.topologyViewer) {
        window.topologyViewer.resetZoom();
    }
}

async function triggerCollection() {
    try {
        const response = await fetch('/api/collect', { method: 'POST' });
        const data = await response.json();

        if (data.success) {
            window.topologyViewer.showMessage('数据收集已触发，正在刷新...', 'success');
            
            // 延迟刷新数据
            setTimeout(() => {
                window.topologyViewer.loadTopologyData();
            }, 2000);
        } else {
            window.topologyViewer.showMessage('触发数据收集失败: ' + data.message, 'error');
        }
    } catch (error) {
        window.topologyViewer.showMessage('请求失败: ' + error.message, 'error');
    }
}

function goToMainPage() {
    window.location.href = '/';
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
    console.log('🚀 网络拓扑图页面加载完成');
    window.topologyViewer = new TopologyViewer();
});